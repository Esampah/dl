Instalasi

	 1. Install TiktokBot.exe
    2. Download ChromeDriver di sini https://googlechromelabs.github.io/chrome-for-testing/ 
        (Sesuaikan dengan Versi Chrome Browser yang di Gunakan saat ini Pilih yang Versi Stable/Stabil) 
    3. Extract dan Pindahkan ChromeDriver.exe ke Folder TiktokBot
	 4. Buka folder KeyGen dan Pindahkan Ke Folder Penginstalan Tiktokbot untuk Aktivasi dan Selesai




	 it'Sell, Thank You..
	 https://lynk.id/itsell