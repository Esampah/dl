Instalasi

	 1. Install InstaBot.exe
     2. Download ChromeDriver di sini https://googlechromelabs.github.io/chrome-for-testing/ 
        (Sesuaikan dengan Versi Chrome Browser yang di Gunakan saat ini Pilih yang Versi Stable/Stabil) 
     3. Extract dan Pindahkan ChromeDriver.exe ke Folder InstaBot
	 4. Jalankan KeyGen.exe untuk Aktivasi dan Selesai




	 it'Sell, Thank You..
	 https://lynk.id/itsell