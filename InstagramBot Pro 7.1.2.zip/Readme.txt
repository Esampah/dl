Instalasi:

	 1. Install Software InstagramBot
     2. Buka Keygen
     3. Generate Keygen
	 4. Buka Aplikasi